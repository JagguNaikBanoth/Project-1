# Delhi_house_prediction
The aim of this project to predict the price of the houses in Delhi, in various localities,
based on the data present in the dataset. The dataset is from Kaggle. The project aims to
predicts the house price, by analysing the feautures such as area, number of bedrooms,
locality and many more. The dataset has 1259 rows and 11 columns
